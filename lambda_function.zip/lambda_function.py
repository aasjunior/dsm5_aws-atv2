import sys
import logging
import pymysql
import json
import os

# Configuração do logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# rds settings
user_name = os.environ.get('USER_NAME')
password = os.environ.get('PASSWORD')
rds_proxy_host = os.environ.get('RDS_PROXY_HOST')
db_name = os.environ.get('DB_NAME')

# Verifica se todas as variáveis de ambiente necessárias estão definidas
if not all([user_name, password, rds_proxy_host, db_name]):
    logger.error("ERROR: Environment variables are not set properly.")
    sys.exit(1)

def lambda_handler(event, context):
    """
    This function fetches data from the event and writes records to the RDS MySQL table.
    """
    # Estabelece a conexão com o banco de dados RDS MySQL
    try:
        conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
        logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")
        
        # Verifica se a chave 'body' existe no evento
        if 'body' in event:
            # Se 'body' for uma string, converte para um dicionário
            if isinstance(event['body'], str):
                data = json.loads(event['body'])
            else:
                # Se 'body' já for um dicionário, usa diretamente
                data = event['body']
        else:
            # Se a chave 'body' não existir, usa o evento diretamente
            data = event
            
        # Prepara os dados para inserção
        FirstName = data.get('FirstName')
        LastName = data.get('LastName')
        BirthDate = data.get('BirthDate')
        Gender = data.get('Gender')

        # String SQL para inserção de dados
        sql_string = 'INSERT INTO Patient (FirstName, LastName, BirthDate, Gender) VALUES (%s, %s, %s, %s)'

        # Executa as operações SQL
        with conn.cursor() as cur:
            cur.execute('''
                CREATE TABLE IF NOT EXISTS Patient (
                    PatientID INT NOT NULL AUTO_INCREMENT, 
                    FirstName VARCHAR(255) NOT NULL, 
                    LastName VARCHAR(255) NOT NULL,
                    BirthDate VARCHAR(10) NOT NULL,
                    Gender VARCHAR(6) NOT NULL,
                    PRIMARY KEY (PatientID)
                )
            ''')
            cur.execute(sql_string, (FirstName, LastName, BirthDate, Gender))
            conn.commit()
            cur.execute('SELECT * FROM Patient')
            logger.info('The following items have been added to the database:')
            for row in cur:
                logger.info(row)
            conn.commit()
    except pymysql.MySQLError as e:
        logger.error("ERROR: Unexpected error during database operations.")
        logger.error(e)
    finally:
        # Verifica se a conexão ainda está aberta antes de tentar fechá-la
        if conn.open:
            conn.close()

    # Retorna uma mensagem de sucesso
    return {
        "statusCode": 200,
        "body": json.dumps("Records successfully added to RDS for MySQL table")
    }
